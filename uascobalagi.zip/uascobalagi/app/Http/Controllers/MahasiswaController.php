<?php

namespace App\Http\Controllers;
use App\Models\Mahasiswa;
use App\Http\Requests\MahasiswaRequest;

use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function tampil() {
        $m = Mahasiswa::all();       
        return view('tampil', ['mhs' => $m]);
    }

    //tampilan view tambah
    public function create() {
        return view('tugas.tambah');
    }

    //proses tambah
    public function store(MahasiswaRequest $req) {
        Mahasiswa::create([
            'nim' => $req->nim,
            'nama' => $req->nama,
            'ipk' => $req->ipk,
            'tanggal_lahir' => $req->tanggal_lahir
        ]);
        return redirect('/');    
    }

    //Menampilkan form edit dan delete
    public function edit($id) {
        $m = Mahasiswa::find($id);
        return view('tugas.ubah', compact('m'));
    }

    public function delete($id) {
        $m = Mahasiswa::find($id);
        return view('tugas.hapus', compact('m'));
    }

    //proses edit dan delete
    public function update(MahasiswaRequest $req, $id) {
        $m = Mahasiswa::find($id);
        $m->update([
            'nim' => $req->nim,
            'nama' => $req->nama,
            'ipk' => $req->ipk,
            'tanggal_lahir' => $req->tanggal_lahir
        ]);
        return redirect('/');
    }

    public function destroy($id) {
        $m = Mahasiswa::find($id);
        $m->delete();
        return redirect('/');
    }
}
