
<?php $__env->startSection('isi'); ?>

<div class="mt-5 mx-auto" style="width: 380px">
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(url("/tugas/$m->id")); ?>" method="POST">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <div class="mb-3">
                    <label for="" class="form-label">Nama : <?php echo e(old('nim', $m->nim)); ?></label>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Deskripsi : <?php echo e(old('nama', $m->nama)); ?></label>
                </div>
                <button type="submit" class="btn btn-primary">Hapus</button>
                <button type="button" onclick="history.go(-1)" 
                    class="btn btn-danger">Batal</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LaravelSA02\uascobalagi\resources\views/tugas/hapus.blade.php ENDPATH**/ ?>