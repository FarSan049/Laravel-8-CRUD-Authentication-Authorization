<footer>        
    <div class="text-center">Copyright(c) Fariz Ikhsan</div>
</footer>
<?php /**PATH C:\LaravelSA02\uascobalagi\resources\views/komponen/footer.blade.php ENDPATH**/ ?>