

<?php $__env->startSection('isi'); ?>
    <div class="border rounded mt-5 mx-auto d-flex flex-column align-items-stretch bg-white" style="width: 380px;">
        <div class="d-flex justify-content-between flex-shrink-0 p-3 link-dark  border-bottom">
            <span class="fs-5 fw-semibold">Task Lists</span>
            <a href="<?php echo e(url('/create')); ?>" class="btn btn-sm btn-primary">
                add</a>
        </div>

        <?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-group list-group-flush border-bottom scrollarea">
            <div class="list-group-item list-group-item-action py-3 lh-tight" aria-current="true">
                <div class="d-flex w-100 align-items-center justify-content-between">
                    <strong class="mb-1"><?php echo e($item->nim); ?></strong>
                    <small><?php echo e($item->ipk); ?></small>
                </div>
                <div class="col-10 mb-1 small"><?php echo e($item->nama); ?></div>
                <div class="group-action">
                    <a href="<?php echo e(url("/tugas/$item->id/edit")); ?>" class="badge bg-info text-white">edit</a>
                    <a href="<?php echo e(url("/tugas/$item->id/delete")); ?>" class="badge bg-danger text-white">delete</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LaravelSA02\uascobalagi\resources\views/tampil.blade.php ENDPATH**/ ?>