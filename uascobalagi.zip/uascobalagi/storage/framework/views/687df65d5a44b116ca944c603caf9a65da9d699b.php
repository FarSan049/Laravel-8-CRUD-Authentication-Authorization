<header class="p-1 bg-dark text-white">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="<?php echo e(url('/')); ?>" class="nav-link px-2 text-white">Home</a></li>
            </ul>
            <div class="text-end">
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" type="button" class="btn btn-outline-light me-2">Login</a>
                <a href="<?php echo e(route('register')); ?>" type="button" class="btn btn-warning">Sign-up</a>
                <?php else: ?>

                <table border="0" cellpadding="0">
                    <tr>
                        <td>Selamat Datang <?php echo e(Auth::user()->name); ?> (<?php echo e(Auth::user()->role); ?>), keluar klik &nbsp;</td>
                        <td>
                            <form action="<?php echo e(route('logout')); ?>" id="logout-form" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Logout</button>
                            </form>
                        </td>
                    </tr>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\LaravelSA02\uascobalagi\resources\views/komponen/header.blade.php ENDPATH**/ ?>