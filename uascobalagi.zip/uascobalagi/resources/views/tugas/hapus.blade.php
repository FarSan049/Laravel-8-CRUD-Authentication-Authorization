@extends('layout')
@section('isi')

<div class="mt-5 mx-auto" style="width: 380px">
    <div class="card">
        <div class="card-body">
            <form action="{{ url("/tugas/$m->id") }}" method="POST">
                @csrf @method('DELETE')
                <div class="mb-3">
                    <label for="" class="form-label">Nama : {{ old('nim', $m->nim) }}</label>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Deskripsi : {{ old('nama', $m->nama) }}</label>
                </div>
                <button type="submit" class="btn btn-primary">Hapus</button>
                <button type="button" onclick="history.go(-1)" 
                    class="btn btn-danger">Batal</button>
            </form>
        </div>
    </div>
</div>

@endsection