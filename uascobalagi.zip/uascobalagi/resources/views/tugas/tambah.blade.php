@extends('layout')
@section('isi')

<div class="mt-5 mx-auto" style="width: 380px">
    <div class="card">
        <div class="card-body">
            <form action="{{ url('/') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="" class="form-label">Nim</label>
                    <input type="number" name="nim" maxlength="7" min="1300001" max="1399999" class="form-control" value="{{ old('nim') }}">
                @error('nim')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama') }}">
                @error('nama')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">IPK</label>
                    <input type="number" name="ipk" maxlength="4" min="0" max="4" step="0.01" class="form-control" value="{{ old('ipk') }}">
                @error('ipk')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" value="{{ old('ipk') }}">
                    @error('tanggal_lahir')
                    <div class="span text-danger">
                        {{ $message }}
                    </div>
                    
                @enderror
                </div>
                <button type="submit" class="btn btn-primary">Tambah</button>
                <button type="button" onclick="history.go(-1)" 
                    class="btn btn-danger">Batal</button>
            </form>
        </div>
    </div>
</div>

@endsection