@extends('layout')
@section('isi')

<div class="mt-5 mx-auto" style="width: 380px">
    <div class="card">
        <div class="card-body">
            <form action="{{ url("/tugas/$m->id") }}" method="POST">
                @csrf @method('PATCH')
                <div class="mb-3">
                    <label for="" class="form-label">Nim</label>
                    <input type="number" name="nim"  maxlength="7" min="1300001" max="1399999" class="form-control" value="{{ old('nim', $m->nim )}}">
                @error('nim')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama', $m->nama) }}">
                @error('nama')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">IPK</label>
                    <input type="number" name="ipk" maxlength="7" min="0" max="4" step="0.01" class="form-control" value="{{ old('ipk', $m->ipk) }}">
                @error('ipk')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" value="{{ old('tanggal_lahir', $m->tanggal_lahir) }}">
                    @error('tanggal_lahir')
                    <div class="span text-danger">
                        {{ $message }}
                    </div>
                        
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary">Ubah</button>
                <button type="button" onclick="history.go(-1)" 
                    class="btn btn-danger">Batal</button>
            </form>
        </div>
    </div>
</div>

@endsection