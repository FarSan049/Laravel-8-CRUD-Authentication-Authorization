<footer>        
    <div class="text-center">Copyright(c) Fariz Ikhsan</div>
</footer>
