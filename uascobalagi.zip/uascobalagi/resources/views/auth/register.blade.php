@extends('layout')
@section('isi')

<div class="mt-5 mx-auto" style="width: 380px">
    <div class="card">
        <div class="card-body">
            <form action="{{ route('register') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="" class="form-label">Nama</label>
                    <input type="text" name="name" class="form-control" value="{{ old('name') }}">
                @error('name')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Email</label>
                    <input type="text" name="email" class="form-control" value="{{ old('email') }}">
                @error('email')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Role</label>
                    <input type="text" name="role" class="form-control" value="{{ old('role') }}">
                @error('role')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>
                
                <div class="mb-3">
                    <label for="" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" value="{{ old('password') }}">
                @error('password')
                <div class="span text-danger">
                    {{ $message }}
                </div>
                    
                @enderror
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control" value="{{ old('password_confirmation') }}">
                </div>

                <button type="submit" class="btn btn-primary">Daftar</button>
                <button type="button" onclick="history.go(-1)" 
                    class="btn btn-danger">Batal</button>
            </form>
        </div>
    </div>
</div>

@endsection