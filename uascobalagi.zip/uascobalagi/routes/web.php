<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MahasiswaController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [MahasiswaController::class, 'tampil']);

//Menampilkan Form baru untuk tambah data
Route::get('/create', [MahasiswaController::class, 'create'])->middleware('is_admindosen');
Route::post('/', [MahasiswaController::class, 'store'])->middleware('is_admindosen');

//Menampilkan Data Form Ubah dan Delete
Route::get('/tugas/{id}/edit', [MahasiswaController::class, 'edit'])->middleware('is_admin');
Route::patch('/tugas/{id}', [MahasiswaController::class, 'update'])->middleware('is_admin');

//Proses Ubah dan Delete
Route::get('/tugas/{id}/delete', [MahasiswaController::class, 'delete'])->middleware('is_admin');
Route::delete('/tugas/{id}', [MahasiswaController::class, 'destroy'])->middleware('is_admin');
